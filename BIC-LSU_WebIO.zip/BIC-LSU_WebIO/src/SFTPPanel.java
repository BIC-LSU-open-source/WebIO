/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Chui
 */

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.NumberFormat;
import javax.swing.text.NumberFormatter;
import java.beans.*; //property change stuff

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFileChooser;

import java.io.*;

import java.util.Vector;

import com.jcraft.jsch.*;

public class SFTPPanel extends JPanel implements ActionListener {
    
    String string_transfer_application, operation, 
        path_mode_allowed, storage_server_FQDN, 
        SSH_server_port, FDT_server_port, 
        SSH_server_credential_duration, storage_space_root_path, 
        string_chooser_FDT_approve_button, string_chooser_path_approve_button, 
        string_prompt_invariant, command_line_FDT;
    
    String[] SSH_server_credential;
    
    File path_FDT;
    
    JFileChooser chooser_FDT, chooser_path;
    
    JTextArea textArea;
    
    SFTPPanel(String[] args) {
        
        super(new GridBagLayout());
        
        string_transfer_application = "SFTP";
        
        path_FDT = null;
        
        chooser_FDT = new JFileChooser();
        
        chooser_FDT.setDialogType(JFileChooser.OPEN_DIALOG);
        chooser_FDT.setApproveButtonText("Locate FDT");
        chooser_FDT.setApproveButtonToolTipText("Locate the JAR file of the FDT.");
        chooser_FDT.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser_FDT.setMultiSelectionEnabled(false);
        chooser_FDT.addActionListener(this);
        
        operation = args[7]; //operation
        
        path_mode_allowed = args[8]; //allowed path mode
        
        storage_server_FQDN = args[0];
        
        SSH_server_port = args[1];
        
        FDT_server_port = args[2];
        
        SSH_server_credential = new String[2];
        
        SSH_server_credential[0] = args[3];    //user name
        SSH_server_credential[1] = args[4];    //password
        
        SSH_server_credential_duration = args[5];
        
        storage_space_root_path = args[6];
        
        setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createTitledBorder("Local File System"),
                        BorderFactory.createEmptyBorder(1,1,1,1)));
        
        if (operation.equals("download")) {
            string_chooser_path_approve_button = "Download";
        } else if (operation.equals("upload")) {
            string_chooser_path_approve_button = "Upload";
        } else {
            string_chooser_path_approve_button = "INVALID OPERATION!";
        }
        
        int path_mode;
        
        if (path_mode_allowed.equals("file")) {
            path_mode = JFileChooser.FILES_ONLY;
        } else if (path_mode_allowed.equals("directory")) {
            path_mode = JFileChooser.DIRECTORIES_ONLY;
        } else if (path_mode_allowed.equals("both")) {
            path_mode = JFileChooser.FILES_AND_DIRECTORIES;
        } else {
            path_mode = -1;
        }
        
        chooser_path = new JFileChooser();
        
        chooser_path.setDialogType(JFileChooser.OPEN_DIALOG);
        chooser_path.setApproveButtonText(string_chooser_path_approve_button);
        chooser_path.setApproveButtonToolTipText("Start transmission.");
        chooser_path.setFileSelectionMode(path_mode);
        chooser_path.setMultiSelectionEnabled(true);
        chooser_path.addActionListener(this);
        
        /*
        fc.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)  {
        //System.out.println("Action");
      String command = e.getActionCommand();
        if (command.equals(JFileChooser.APPROVE_SELECTION)) {
          File[] selected_paths = fc.getSelectedFiles();
          
          System.out.println("local path: " + selectedFile.getAbsolutePath());
          System.out.println(selectedFile.getParent());
          System.out.println(selectedFile.getName());
          
          
          transferPaths(SFTPServer, SFTPCredential, operation, path_remote_root, selected_paths);
          
          JOptionPane.showMessageDialog(
                  null, 
                  "All transmissions successfully finished!\nClick \"Cancel\" to close this program, " +
                  "and then click \"Finish\" on BIC LSU web page.", 
                  "Summary", 
                  JOptionPane.INFORMATION_MESSAGE);
          
        } else if (command.equals(JFileChooser.CANCEL_SELECTION)) {
          //System.out.println(JFileChooser.CANCEL_SELECTION);
          System.exit(0);
        }
        

      }
    });
        */
        /*
        JTextArea textArea = 
            new JTextArea(
            "The storage server is at \"" + SFTPServer[0] + "\".\n" +
            "The credential (effective during the next " + credential_duration + " minutes) is\n" +
            "User Name: " + SFTPCredential[0] + "\n" + 
            "Password: " + SFTPCredential[1] + "\n" +
            "Alternative Transfer Applications are\n" +
            "(1) Any SFTP client.  Connect to Port " + SFTPServer[1] + ".\n" +
            "(2) Any GridFTP-over-SSH client.  Connect to Port " + GridFTPServer_port + ".\n" +
            "(3) FDT in SCP mode.  Connect to Port " + FDTServer_port + ".\n" +
            "Transfer data under Directory \"" + path_remote_root + "\" on the storage server.");
        */
        
        string_prompt_invariant = 
            "The one-time credential bundled in this application is effective in the next " + 
            SSH_server_credential_duration + " minutes.";
        
        textArea = new JTextArea(string_prompt_invariant + "\nTransfer with SFTP.");
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
 
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        add(scrollPane, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        add(chooser_FDT, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        add(chooser_path, c);
        
        /*
        // keyboard-interactive
        try{
                String one_time_password = SSH_server_credential[1];
            
                JSch jsch=new JSch();

                
                String host=null;
                host=JOptionPane.showInputDialog("Enter username@hostname",
                    System.getProperty("user.name")+"@localhost"); 
                
                String user=host.substring(0, host.indexOf('@'));
                host=host.substring(host.indexOf('@')+1);

                Session session=jsch.getSession(user, host, 22);
                
                Session session = 
                    jsch.getSession(
                        SSH_server_credential[0], 
                        storage_server_FQDN, 
                        Integer.parseInt(SSH_server_port));

                // username and passphrase will be given via UserInfo interface.
                UserInfo ui=new MyUserInfo(one_time_password);
                session.setUserInfo(ui);
                session.connect();

                Channel channel=session.openChannel("shell");

                channel.setInputStream(System.in);
                channel.setOutputStream(System.out);

                channel.connect();
        }
        catch(Exception e){
            System.out.println(e);
        }
        //*/
        
    }
    
    
    public void actionPerformed(ActionEvent e)  {
        //System.out.println("Action");
        Object source = e.getSource();
        String command = e.getActionCommand();
        
        if (source == chooser_FDT) {
            
            if (command.equals(JFileChooser.APPROVE_SELECTION)) {
                
                path_FDT = chooser_FDT.getSelectedFile();
                /*
                System.out.println("FDT path: " + path_FDT.getAbsolutePath());
                System.out.println(path_FDT.getParent());
                System.out.println(path_FDT.getName());
                */
                string_transfer_application = "FDT";

            } else if (command.equals(JFileChooser.CANCEL_SELECTION)) {
                System.out.println(JFileChooser.CANCEL_SELECTION);

                path_FDT = null;
                string_transfer_application = "SFTP";

            }
            
            textArea.setText(string_prompt_invariant + "\nTransfer with " + string_transfer_application + ".");
        
        } else if (source == chooser_path) {
            
            if (command.equals(JFileChooser.APPROVE_SELECTION)) {
                
                String summary_prompt_message = 
                    "Close this application and then click \"Finish\" on BIC-LSU web page.";
                
                int exit_code = 0;
                
                File[] selected_paths = chooser_path.getSelectedFiles();

                if (string_transfer_application.equals("FDT")) {
                    
                    try {
                        //File file_list = File.createTempFile("BICLSU", null);
                        //file_list.deleteOnExit();
                        if (operation.equals("upload")) {
                            command_line_FDT = 
                                "java -jar " + path_FDT.getAbsolutePath() + " " +
                                "-sshp " + SSH_server_port + " " +
                                "-remote \"java -jar fdt.jar\"" + " " +
                                "-p " + FDT_server_port + " " +
                                "-r " + selected_paths[0] + " " +
                                SSH_server_credential[0] + "@" + 
                                storage_server_FQDN + ":" +
                                storage_space_root_path;
                        } else if (operation.equals("download")) {
                            command_line_FDT = 
                                "java -jar " + path_FDT.getAbsolutePath() + " " +
                                "-sshp " + SSH_server_port + " " +
                                "-remote \"java -jar fdt.jar\"" + " " +
                                "-p " + FDT_server_port + " " +
                                "-r " + 
                                SSH_server_credential[0] + "@" + 
                                storage_server_FQDN + ":" +
                                storage_space_root_path + " " +
                                selected_paths[0];
                        } else {
                            System.out.println("FDT Cmd: Invalid operation.");
                        }

                        textArea.setText(
                            string_prompt_invariant + 
                            "\nTransfer with FDT.  FDT command line:\n" + 
                            command_line_FDT + 
                            "\nSSH Password: " + SSH_server_credential[1]);

                        summary_prompt_message = 
                            "FDT command line generation successfully finished!\n" +
                            "Run the command line on a terminal.\n" +
                            summary_prompt_message;
                    } catch (Exception exception) {
                        System.out.println(exception.toString());
                        
                        summary_prompt_message = 
                            "FDT command line generation failed!\n" +
                            summary_prompt_message;
                    }
                    
                    
                    
                } else if (string_transfer_application.equals("SFTP")) {
                    //start SFTP;
                    
                    if (transferPaths(
                        storage_server_FQDN, 
                        SSH_server_port, 
                        SSH_server_credential, 
                        operation, 
                        storage_space_root_path, 
                        selected_paths)) {
                        exit_code = 0;
                    } else {
                        exit_code = 1;
                    }
                    
                    if (exit_code == 0) {
                    summary_prompt_message = 
                        "All SFTP transmissions successfully finished!\n" +
                        summary_prompt_message;
                    } else {
                        summary_prompt_message = 
                            "Some SFTP transmissions failed!\n" +
                            summary_prompt_message;
                    }
                } else {
                    System.out.println("Invalid transfer application.");
                }
                
                /*
                StringBuffer output = new StringBuffer();
                Process p;
                int exit_code = 1;
                
                try {
                    
                    command_line_FDT = 
                        "java -jar " + path_FDT.getAbsolutePath() + " " +
                        "-sshp " + SSH_server_port + " " +
                        "-p " + FDT_server_port + " " +
                        "test_file" + " " + 
                        SSH_server_credential[0] + "@" + storage_server_FQDN + ":" +
                        storage_space_root_path;
                    
                    command_line_FDT = "ssh -o PasswordAuthentication=yes -o RSAAuthentication=no -o StrictHostKeyChecking=no sftpuser@192.168.56.11";
                    
                    System.out.println("cmd: " + command_line_FDT);
                    
                    p = Runtime.getRuntime().exec(command_line_FDT);
                    
                    BufferedWriter writer = 
                        new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
                    
                    writer.write(SSH_server_credential[1] + "\n");
                    
                    System.out.println("password provided");
                    
                    exit_code = p.waitFor();
                    
                    System.out.println("fdt finished");
                    
                    BufferedReader reader = 
                        new BufferedReader(new InputStreamReader(p.getInputStream()));

                        String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}
                        
                        System.out.println("stdout");
                        System.out.println(output);
                        
                    reader = 
                            new BufferedReader(new InputStreamReader(p.getErrorStream()));

                        line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}
                        
                        System.out.println("stderr");
                        System.out.println(output);
                        
                        System.out.println("exit code: " + exit_code);
                    transferPaths(SFTPServer, SFTPCredential, operation, path_remote_root, selected_paths);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                */
                
                JOptionPane.showMessageDialog(
                    null, 
                    summary_prompt_message, 
                    "Summary", 
                    JOptionPane.INFORMATION_MESSAGE);

            } else if (command.equals(JFileChooser.CANCEL_SELECTION)) {
              //System.out.println(JFileChooser.CANCEL_SELECTION);
              System.exit(0);
            }
        } else {
            System.out.println("Invalid Action Source");
        }
    }
    
    private 
        boolean 
        transferPaths (
                String storage_server_FQDN, 
                String SSH_port,
                String[] SSH_credential,
                String operation,
                String storage_space_root_path,
                File[] selected_paths) {
                
        /*
        System.out.println("FQDN: " + storage_server_FQDN);
        System.out.println("port: " + SSH_port);
        System.out.println("user name: " + SSH_credential[0]);
        System.out.println("password: " + SSH_credential[1]);
        System.out.println("operation: " + operation);
        for (File one_path : selected_paths) {
            
            System.out.println("one selected path: " + one_path.getAbsolutePath());
            
        }
        */
        
        try {
            //establish an SFTP connection
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            /*
            config.put("PreferredAuthentications", 
                  "publickey,keyboard-interactive,password");
            */
            config.put("PreferredAuthentications", "keyboard-interactive,password");

            JSch ssh;
            Session session;
            Channel channel;
            ChannelSftp sftp;
        
            ssh = new JSch();
            session = 
                ssh.getSession(
                    SSH_server_credential[0], 
                    storage_server_FQDN, 
                    Integer.parseInt(SSH_server_port));
            //session.setConfig(config);
            //session.setPassword(SSH_server_credential[1]);
            //session.connect();
            //channel = session.openChannel("sftp");
            //channel.connect();
            //sftp = (ChannelSftp) channel;
            
            // username and passphrase will be given via UserInfo interface.
            UserInfo ui=new MyUserInfo(SSH_server_credential[1]);
            session.setUserInfo(ui);
            session.connect();
            //Channel channel=session.openChannel("shell");
            channel = session.openChannel("sftp");

            channel.setInputStream(System.in);
            channel.setOutputStream(System.out);

            channel.connect();

            sftp = (ChannelSftp) channel;
            
            try {
                sftp.cd(storage_space_root_path);
            } catch (SftpException e) {
                System.out.println(e.toString());
                
                return false;
            }
            
            if (operation.equals("download")) {
                //only one destination local root directory
                /*
                System.out.println("download from " + storage_space_root_path);
                System.out.println("to " + selected_paths[0]);
                */
                return downloadThisPath(sftp, selected_paths[0]);

            } else {
                //only one destination remote root directory

                //System.out.println("upload from ");
                for (File one_path_to_upload : selected_paths) {
                    //System.out.println(one_path.getAbsolutePath());
                    if (!uploadThisPath(sftp, one_path_to_upload)) {
                        return false;
                    }

                }
                //System.out.println("to " + remote_relative_path);
            }
            
            session.disconnect();
            
            return true;
        }
        /*
        catch (SftpException e) {
            System.out.println(e.toString());
            
            return false;
        }
        */
        catch (JSchException e) {
            System.out.println(e.toString());
            
            return false;
        }
        
    }
    
    private boolean downloadThisPath(ChannelSftp sftp, File path_to_download_to) {
        
        try {
            
            java.util.Vector vv=sftp.ls(".");
	    if(vv!=null){
	      for(int ii=0; ii<vv.size(); ii++){
//		out.println(vv.elementAt(ii).toString());

                Object obj=vv.elementAt(ii);
                if(obj instanceof com.jcraft.jsch.ChannelSftp.LsEntry &&
                    !((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename().equals(".") &&
                    !((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename().equals("..") ){
                    if (((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getAttrs().isDir()) {
                        
                        
                        File path_to_download_to_new = new File(path_to_download_to, ((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename());
                        //System.out.println("local mkdir " + path_to_download_to_new.getAbsolutePath());
                        path_to_download_to_new.mkdir();
                        
                        //System.out.println("sftp cd to " + ((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename());
                        sftp.cd(((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename());
                        
                        //System.out.println("local cd to " + path_to_download_to_new.getAbsolutePath());
                        downloadThisPath(sftp, path_to_download_to_new);
                        
                        //System.out.println("local cd to ..");
                        //System.out.println("sftp cd to ..");
                        sftp.cd("..");
                        
                    } else {
                        File path_to_download_to_file = new File(path_to_download_to, ((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename());
                        System.out.println("download " + ((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename() + " as " + path_to_download_to_file.getAbsolutePath());
                        
                        SftpProgressMonitor monitor=new MyProgressMonitor();
                        int mode=ChannelSftp.OVERWRITE;
                        
                        sftp.get(
                                ((com.jcraft.jsch.ChannelSftp.LsEntry)obj).getFilename(), 
                                path_to_download_to_file.getAbsolutePath(), 
                                monitor, mode);
                        
                    }
                  
                }

	      }
	    }
            
        } catch (SftpException e) {
            System.out.println(e.toString());
            
            return false;
        }
        
        return true;
    }
    
    private boolean uploadThisPath(ChannelSftp sftp, File path_to_upload) {
        
        try {
        
            if (path_to_upload.isDirectory()) {
                //System.out.println("sftp mkdir " + path_to_upload.getName());
                //System.out.println("sftp cd to " + path_to_upload.getName());
                sftp.mkdir(path_to_upload.getName());
                sftp.cd(path_to_upload.getName());
                //System.out.println("local cd to " + path_to_upload.getAbsolutePath());

                for (File one_path_to_upload : path_to_upload.listFiles()) {
                    uploadThisPath(sftp, one_path_to_upload);

                }
                //System.out.println("sftp cd to ..");
                //System.out.println("local cd to ..");
                sftp.cd("..");

            } else {

                SftpProgressMonitor monitor=new MyProgressMonitor();
                int mode=ChannelSftp.OVERWRITE;

                //System.out.println("upload " + path_to_upload.getAbsolutePath() + " as " + path_to_upload.getName());
                sftp.put(path_to_upload.getAbsolutePath(), path_to_upload.getName(), monitor, mode);

            }
        } catch (SftpException e) {
            System.out.println(e.toString());
            
            return false;
        }
        
        return true;
    }
    
    
    
    public static class MyProgressMonitor implements SftpProgressMonitor{
    ProgressMonitor monitor;
    long count=0;
    long max=0;
    public void init(int op, String src, String dest, long max){
      this.max=max;
      monitor=new ProgressMonitor(null,
                                  ((op==SftpProgressMonitor.PUT)?
                                   "put" : "get")+": "+src,
                                  "",  0, (int)max);
      count=0;
      percent=-1;
      monitor.setProgress((int)this.count);
      monitor.setMillisToDecideToPopup(1000);
    }
    private long percent=-1;
    public boolean count(long count){
      this.count+=count;

      if(percent>=this.count*100/max){ return true; }
      percent=this.count*100/max;

      monitor.setNote("Completed "+this.count+"("+percent+"%) out of "+max+".");
      monitor.setProgress((int)this.count);

      return !(monitor.isCanceled());
    }
    public void end(){
      monitor.close();
    }
  }
    
    public static class MyUserInfo implements UserInfo, UIKeyboardInteractive{
        
        final private String one_time_password;
        
        MyUserInfo(String one_time_password) {
            this.one_time_password = one_time_password;
        }
        
        public String getPassword(){ return passwd; }
        /*
        public boolean promptYesNo(String str){
          Object[] options={ "yes", "no" };
          int foo=JOptionPane.showOptionDialog(null, 
                 str,
                 "Warning", 
                 JOptionPane.DEFAULT_OPTION, 
                 JOptionPane.WARNING_MESSAGE,
                 null, options, options[0]);
           return foo==0;
        }
        */
        public boolean promptYesNo(String str){ return true; }

        String passwd;
        JTextField passwordField=(JTextField)new JPasswordField(20);

        public String getPassphrase(){ return null; }
        public boolean promptPassphrase(String message){ return false; }
        public boolean promptPassword(String message){
          Object[] ob={passwordField}; 
          int result=
            JOptionPane.showConfirmDialog(null, ob, message,
                                          JOptionPane.OK_CANCEL_OPTION);
          if(result==JOptionPane.OK_OPTION){
            passwd=passwordField.getText();
            return true;
          }
          else{ 
            return false; 
          }
        }
        public void showMessage(String message){
          JOptionPane.showMessageDialog(null, message);
        }

        /*
        final GridBagConstraints gbc = 
          new GridBagConstraints(0,0,1,1,1,1,
                                 GridBagConstraints.NORTHWEST,
                                 GridBagConstraints.NONE,
                                 new Insets(0,0,0,0),0,0);
        private Container panel;
        public String[] promptKeyboardInteractive(String destination,
                                                  String name,
                                                  String instruction,
                                                  String[] prompt,
                                                  boolean[] echo) {
    
            //System.out.println("promptKeyboardInteractive");
            //System.out.println("destination: "+destination);
            //System.out.println("name: "+name);
            //System.out.println("instruction: "+instruction);
            //System.out.println("prompt.length: "+prompt.length);
            //System.out.println("prompt: "+prompt[0]);
    
          panel = new JPanel();
          panel.setLayout(new GridBagLayout());

          gbc.weightx = 1.0;
          gbc.gridwidth = GridBagConstraints.REMAINDER;
          gbc.gridx = 0;
          panel.add(new JLabel(instruction), gbc);
          gbc.gridy++;

          gbc.gridwidth = GridBagConstraints.RELATIVE;

          JTextField[] texts=new JTextField[prompt.length];
          for(int i=0; i<prompt.length; i++){
            gbc.fill = GridBagConstraints.NONE;
            gbc.gridx = 0;
            gbc.weightx = 1;
            panel.add(new JLabel(prompt[i]),gbc);

            gbc.gridx = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.weighty = 1;
            if(echo[i]){
              texts[i]=new JTextField(20);
            }
            else{
              texts[i]=new JPasswordField(20);
            }
            panel.add(texts[i], gbc);
            gbc.gridy++;
          }

          if(JOptionPane.showConfirmDialog(null, panel, 
                                           destination+": "+name,
                                           JOptionPane.OK_CANCEL_OPTION,
                                           JOptionPane.QUESTION_MESSAGE)
             ==JOptionPane.OK_OPTION){
            String[] response=new String[prompt.length];
            for(int i=0; i<prompt.length; i++){
              response[i]=texts[i].getText();
            }
            return response;
          }
          else{
            return null;  // cancel
          }
        }
        */

        public String[] promptKeyboardInteractive(String destination,
                                                  String name,
                                                  String instruction,
                                                  String[] prompt,
                                                  boolean[] echo) {
            String[] response=new String[1];
            response[0] = this.one_time_password;
            
            return response;
        }
    }
}
